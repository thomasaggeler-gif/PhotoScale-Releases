#!/bin/bash
#
# Photo Scale installieren.command
#
# Optional. macOS behandelt heruntergeladene .command-Dateien oft als
# «beschädigt» und schickt sie in den Papierkorb – dann nie
# doppelklicken, sondern Anleitung.txt in diesem Ordner öffnen.
#
# Wenn dieses Skript trotzdem läuft (z. B. nach xattr im Terminal),
# kopiert es die App nach Programme und startet sie.
#
set -euo pipefail

SKRIPT_ORDNER="$(cd "$(dirname "$0")" && pwd)"
ZIEL="/Applications/PhotoScale.app"

hilfe() {
    echo ""
    echo "macOS blockiert heruntergeladene .command-Dateien als «beschädigt»."
    echo "Bitte Anleitung.txt in diesem Ordner öffnen. Kurz:"
    echo ""
    echo "  1. Terminal öffnen"
    echo "  2. xattr -cr  tippen (Leerzeichen am Ende), diesen Ordner"
    echo "     auf das Terminal ziehen, Return"
    echo "  3. PhotoScale.app nach Programme ziehen"
    echo "  4. Einfügen:"
    echo "     xattr -cr /Applications/PhotoScale.app && open /Applications/PhotoScale.app"
    echo ""
}

finde_app() {
    if [ -d "$SKRIPT_ORDNER/PhotoScale.app" ]; then
        printf '%s\n' "$SKRIPT_ORDNER/PhotoScale.app"
        return 0
    fi

    local gefunden
    gefunden="$(find "$SKRIPT_ORDNER" -maxdepth 2 -name 'PhotoScale.app' -type d 2>/dev/null | head -n 1 || true)"
    if [ -n "$gefunden" ] && [ -d "$gefunden" ]; then
        printf '%s\n' "$gefunden"
        return 0
    fi
    return 1
}

if ! APP_QUELLE="$(finde_app)"; then
    echo "Fehler: PhotoScale.app liegt nicht neben diesem Skript." >&2
    hilfe
    exit 1
fi

echo "==> Entferne Quarantäne von der mitgelieferten App"
if ! xattr -cr "$APP_QUELLE"; then
    echo "Fehler: Quarantäne konnte nicht entfernt werden." >&2
    hilfe
    exit 1
fi

echo "==> Kopiere nach Programme"
rm -rf "$ZIEL"
if ! ditto "$APP_QUELLE" "$ZIEL"; then
    echo "Fehler: Kopieren nach Programme ist fehlgeschlagen." >&2
    hilfe
    exit 1
fi

echo "==> Entferne Quarantäne unter Programme"
if ! xattr -cr "$ZIEL"; then
    echo "Fehler: Quarantäne unter Programme konnte nicht entfernt werden." >&2
    hilfe
    exit 1
fi

echo "==> Starte Photo Scale"
if ! open "$ZIEL"; then
    echo "Fehler: Photo Scale konnte nicht gestartet werden." >&2
    hilfe
    exit 1
fi

echo ""
echo "Fertig. Photo Scale liegt unter Programme und wurde gestartet."
