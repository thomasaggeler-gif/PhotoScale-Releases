#!/bin/bash
#
# Photo Scale installieren.command
#
# Für die Erstinstallation auf einem anderen Mac: entfernt die
# Quarantäne-Attribute (sonst zeigt Gatekeeper oft nur «kann nicht
# geöffnet werden» ohne «Trotzdem öffnen»), kopiert die App nach
# Programme und startet sie.
#
# Kein kostenpflichtiges Apple-Konto nötig. Ein Safari-artiges
# Doppelklick ohne Hinweis braucht Developer ID plus Notarisierung.
#
set -euo pipefail

SKRIPT_ORDNER="$(cd "$(dirname "$0")" && pwd)"
ZIEL="/Applications/PhotoScale.app"

finde_app() {
    if [ -d "$SKRIPT_ORDNER/PhotoScale.app" ]; then
        printf '%s\n' "$SKRIPT_ORDNER/PhotoScale.app"
        return 0
    fi

    # Zip mit --keepParent: PhotoScale.app ist das einzige Element
    # (direkt im Skriptordner oder eine Ebene tiefer nach dem Entpacken).
    local gefunden
    gefunden="$(find "$SKRIPT_ORDNER" -maxdepth 2 -name 'PhotoScale.app' -type d 2>/dev/null | head -n 1 || true)"
    if [ -n "$gefunden" ] && [ -d "$gefunden" ]; then
        printf '%s\n' "$gefunden"
        return 0
    fi

    echo "Fehler: PhotoScale.app liegt nicht neben diesem Skript." >&2
    echo "Bitte den Ordner aus dem Installieren-Zip verwenden." >&2
    exit 1
}

APP_QUELLE="$(finde_app)"

echo "==> Entferne Quarantäne von der mitgelieferten App"
xattr -cr "$APP_QUELLE"

echo "==> Kopiere nach Programme"
rm -rf "$ZIEL"
ditto "$APP_QUELLE" "$ZIEL"

echo "==> Entferne Quarantäne unter Programme"
xattr -cr "$ZIEL"

echo "==> Starte Photo Scale"
open "$ZIEL"

echo ""
echo "Fertig. Photo Scale liegt unter Programme und wurde gestartet."
